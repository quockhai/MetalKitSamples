//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

//#import "ParticleView.h"

//struct Vector4 {
//    CGFloat x;
//    CGFloat y;
//    CGFloat z;
//    CGFloat w;
//} Vector4;
//
//struct Particle {
//    struct Vector4 A;
//    struct Vector4 B;
//    struct Vector4 C;
//    struct Vector4 D;
//} Particle;
//
//struct ParticleColor {
//    CGFloat R;
//    CGFloat G;
//    CGFloat B;
//    CGFloat A;
//} ParticleColor;
//
//enum ParticleCount {
//    QtrMillion = 65536,
//    HalfMillion = 131072,
//    OneMillion =  262144,
//    TwoMillion =  524288,
//    FourMillion = 1048576,
//    EightMillion = 2097152,
//    SixteenMillion = 4194304
//};
//
//enum GravityWell {
//    One = 1, //0
//    Two = 2,
//    Three = 3,
//    Four = 4
//};
