//
//  MetalParticleView.h
//  ParticleLab
//
//  Created by quockhai on 2019/3/7.
//  Copyright © 2019 Polymath. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MetalKit/MetalKit.h>
#import <MetalPerformanceShaders/MetalPerformanceShaders.h>


@interface MetalParticleView : NSObject

@end
